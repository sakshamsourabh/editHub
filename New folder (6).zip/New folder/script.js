<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Marketplace MVP — Profiles & Booking</title>
  <meta name="theme-color" content="#111827" />
  <style>
    body { font-family: Arial, sans-serif; margin: 0; padding: 0; background: #f9fafb; color: #111827; }
    header { position: sticky; top: 0; background: white; border-bottom: 1px solid #e5e7eb; display: flex; justify-content: space-between; align-items: center; padding: 10px 20px; }
    header h1 { margin: 0; font-size: 18px; font-weight: bold; }
    header p { margin: 0; font-size: 12px; color: #6b7280; }
    .logo { display: flex; align-items: center; gap: 10px; }
    .logo-box { width: 40px; height: 40px; background: #111827; color: #fff; display: flex; align-items: center; justify-content: center; border-radius: 10px; font-weight: bold; }
    nav button { margin-left: 5px; padding: 6px 12px; border-radius: 8px; font-size: 14px; border: none; cursor: pointer; }
    .btn-primary { background: #111827; color: white; }
    .btn-ghost { background: white; border: 1px solid #d1d5db; }
    .badge { background: #f9fafb; border: 1px solid #e5e7eb; font-size: 12px; font-weight: bold; padding: 4px 8px; border-radius: 6px; }
    main { max-width: 1200px; margin: auto; padding: 20px; }
    h2 { font-size: 22px; font-weight: 600; margin-bottom: 8px; }
    .card { background: white; border: 1px solid #e5e7eb; border-radius: 16px; padding: 20px; margin-bottom: 20px; box-shadow: 0 2px 5px rgba(0,0,0,0.05); }
    .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; }
    .card h3 { margin: 0; font-size: 18px; font-weight: bold; }
    .card p { margin: 5px 0; color: #6b7280; font-size: 14px; }
    .input { width: 100%; padding: 10px; border: 1px solid #d1d5db; border-radius: 8px; margin: 5px 0; }
    #modal { position: fixed; inset: 0; background: rgba(0,0,0,0.5); display: none; justify-content: center; align-items: center; }
    #modal .box { background: white; border-radius: 16px; padding: 20px; max-width: 400px; width: 100%; }
    #modal h3 { margin: 0 0 10px; }
  </style>
</head>
<body>
  <header>
    <div class="logo">
      <div class="logo-box">M</div>
      <div>
        <h1>Marketplace</h1>
        <p>Profiles • Booking • Admin</p>
      </div>
    </div>
    <nav id="navActions">
      <button id="loginBtn" class="btn-ghost">Login</button>
      <button id="signupBtn" class="btn-primary">Sign Up</button>
    </nav>
  </header>

  <main>
    <section id="view-home">
      <h2>Browse Professionals</h2>
      <div class="grid" id="profiles-grid"></div>
    </section>
  </main>

  <div id="modal">
    <div class="box">
      <h3 id="modalName">Book User</h3>
      <button id="callBtn" class="btn-primary">Call</button>
      <button id="msgBtn" class="btn-ghost">Message</button>
      <button id="closeModal" class="btn-ghost">Close</button>
    </div>
  </div>

  <script>
    const profiles = [
      { name: "John Doe", phone: "+919999999999", rate: 500 },
      { name: "Jane Smith", phone: "+918888888888", rate: 750 },
      { name: "Ravi Kumar", phone: "+917777777777", rate: 600 }
    ];

    const grid = document.getElementById("profiles-grid");
    const modal = document.getElementById("modal");
    const modalName = document.getElementById("modalName");
    const callBtn = document.getElementById("callBtn");
    const msgBtn = document.getElementById("msgBtn");
    const closeModal = document.getElementById("closeModal");

    function renderProfiles() {
      grid.innerHTML = "";
      profiles.forEach((profile, index) => {
        const card = document.createElement("div");
        card.className = "card";
        card.innerHTML = `
          <h3>${profile.name}</h3>
          <p>${profile.phone}</p>
          <span class="badge">₹${profile.rate}</span>
          <button class="btn-primary" onclick="openModal(${index})">Book Now</button>
        `;
        grid.appendChild(card);
      });
    }

    function openModal(index) {
      const profile = profiles[index];
      modal.style.display = "flex";
      modalName.textContent = `Book ${profile.name}`;
      callBtn.onclick = () => window.location.href = `tel:${profile.phone}`;
      msgBtn.onclick = () => window.location.href = `sms:${profile.phone}`;
    }

    closeModal.onclick = () => modal.style.display = "none";

    renderProfiles();
  </script>
</body>
</html>
